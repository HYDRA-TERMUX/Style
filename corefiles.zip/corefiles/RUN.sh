#!/bin/bash
#logo random
source ./logo.sh

menu() {
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m01\e[0m\e[1;31m]\e[0m\e[1;32m CHANGE FONT\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m02\e[0m\e[1;31m]\e[0m\e[1;32m CHANGE THEME\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m03\e[0m\e[1;31m]\e[0m\e[1;32m CLICK TO DEFAULT\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m04\e[0m\e[1;31m]\e[0m\e[1;32m UPDATE STYLE\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m05\e[0m\e[1;31m]\e[0m\e[1;32m ABOUT US\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m06\e[0m\e[1;31m]\e[0m\e[1;32m EXIT\e[0m\n"
printf "\e[0m\n"
read -p $' \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Select an option: \e[0m\e[1;96m\en' option
if [[ $option == 1 || $option == 01 ]]; then
cfonts
elif [[ $option == 2 || $option == 02 ]]; then
cthemes
elif [[ $option == 3 || $option == 03 ]]; then
sleep 2
rm $HOME/.termux/font.ttf
rm $HOME/.termux/colors.properties
termux-reload-settings
banner
printf "\e[0m\n"
printf "\e[0m\n"
printf "\e[1;32m Successfully CLICK TO DEFAULT !!\e[0m\n"
sleep 2
banner
menu
elif [[ $option == 4 || $option == 04 ]]; then
git pull origin
clear
banner
printf "\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\e[1;32m  Successfully UPDATE !!\e[0m\n"
printf "\e[0m\n"
elif [[ $option == 5 || $option == 05 ]]; then
sleep 2
termux-open-url https://github.com/HYDRA-TERMUX
banner
menu
elif [[ $option == 6 || $option == 06 ]]; then
sleep 1
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
else
printf " \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\e[1;93m Invalid option \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\n"
sleep 1
banner
menu
fi
}
cfonts() {
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m01\e[0m\e[1;31m]\e[0m\e[1;32m Anonymous Pro   \e[0m\e[1;31m[\e[0m\e[1;37m12\e[0m\e[1;31m]\e[0m\e[1;32m Inconsolata\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m02\e[0m\e[1;31m]\e[0m\e[1;32m Courier Prime   \e[0m\e[1;31m[\e[0m\e[1;37m13\e[0m\e[1;31m]\e[0m\e[1;32m Iosevka\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m03\e[0m\e[1;31m]\e[0m\e[1;32m D2 Coding       \e[0m\e[1;31m[\e[0m\e[1;37m14\e[0m\e[1;31m]\e[0m\e[1;32m LiberationMono\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m04\e[0m\e[1;31m]\e[0m\e[1;32m DejaVu          \e[0m\e[1;31m[\e[0m\e[1;37m15\e[0m\e[1;31m]\e[0m\e[1;32m Meslo\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m05\e[0m\e[1;31m]\e[0m\e[1;32m Fantasque       \e[0m\e[1;31m[\e[0m\e[1;37m16\e[0m\e[1;31m]\e[0m\e[1;32m Monofur\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m06\e[0m\e[1;31m]\e[0m\e[1;32m Fira            \e[0m\e[1;31m[\e[0m\e[1;37m17\e[0m\e[1;31m]\e[0m\e[1;32m Monoid\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m07\e[0m\e[1;31m]\e[0m\e[1;32m FiraCode        \e[0m\e[1;31m[\e[0m\e[1;37m18\e[0m\e[1;31m]\e[0m\e[1;32m OpenDyslexic\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m08\e[0m\e[1;31m]\e[0m\e[1;32m GNU FreeFont    \e[0m\e[1;31m[\e[0m\e[1;37m19\e[0m\e[1;31m]\e[0m\e[1;32m Roboto\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m09\e[0m\e[1;31m]\e[0m\e[1;32m Go              \e[0m\e[1;31m[\e[0m\e[1;37m20\e[0m\e[1;31m]\e[0m\e[1;32m Source Code Pro\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m10\e[0m\e[1;31m]\e[0m\e[1;32m Hack            \e[0m\e[1;31m[\e[0m\e[1;37m21\e[0m\e[1;31m]\e[0m\e[1;32m Terminus\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m11\e[0m\e[1;31m]\e[0m\e[1;32m Hermit          \e[0m\e[1;31m[\e[0m\e[1;37m22\e[0m\e[1;31m]\e[0m\e[1;32m Ubuntu\e[0m\n"
printf "\e[0m\n"
read -p $' \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Select an option: \e[0m\e[1;96m\en' option
if [[ $option == 1 || $option == 01 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Anonymous Pro ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/1.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Anonymous Pro Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 2 || $option == 02 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Courier Prime ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/2.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Courier Prime Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 3 || $option == 03 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing D2 Coding  ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/3.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m D2 Coding  Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 4 || $option == 04 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing DejaVu ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/4.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m DejaVu Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 5 || $option == 05 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Fantasque ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/5.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Fantasque Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 6 || $option == 06 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Fira ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/6.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Fira Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 7 || $option == 07 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing FiraCode ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/7.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m FiraCode Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 8 || $option == 08 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing GNU FreeFont ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/8.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m GNU FreeFont Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 9 || $option == 09 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Go ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/9.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Go Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 10 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Hack ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/10.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Hack Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 11 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Hermit ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/11.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Hermit Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 12 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Inconsolata ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/12.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Inconsolata Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 13 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Iosevka ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/13.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Iosevka Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 14 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing LiberationMono ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/14.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m LiberationMono Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 15 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Meslo ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/15.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Meslo Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 16 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Monofur ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/16.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Monofur Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 17 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Monoid ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/17.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Monoid Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 18 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing OpenDyslexic ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/18.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m OpenDyslexic Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 19 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Roboto ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/19.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Roboto Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 20 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Source Code Pro ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/20.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Source Code Pro Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 21 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Terminus ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/21.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Terminus Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 22 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Ubuntu ..\e[0m\n"
rm $HOME/.termux/font.ttf
cp .corefiles/font/22.ttf $HOME/.termux/font.ttf
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Ubuntu Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
else
printf " \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\e[1;93m Invalid option \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\n"
sleep 1
banner
menu
fi
}
cthemes() {
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m01\e[0m\e[1;31m]\e[0m\e[1;32m LIGHT BACKGROUNDS\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m02\e[0m\e[1;31m]\e[0m\e[1;32m DARK BACKGROUNDS\e[0m\n"
printf "\e[0m\n"
read -p $' \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Select an option: \e[0m\e[1;96m\en' option
if [[ $option == 1 || $option == 01 ]]; then
lightthemes
elif [[ $option == 2 || $option == 02 ]]; then
darkthemes
else
printf " \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\e[1;93m Invalid option \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\n"
sleep 1
banner
menu
fi
}
lightthemes() {
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m01\e[0m\e[1;31m]\e[0m\e[1;32m 3024            \e[0m\e[1;31m [\e[0m\e[1;37m11\e[0m\e[1;31m]\e[0m\e[1;32m Bright\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m02\e[0m\e[1;31m]\e[0m\e[1;32m Apathy          \e[0m\e[1;31m [\e[0m\e[1;37m12\e[0m\e[1;31m]\e[0m\e[1;32m Chalk\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m03\e[0m\e[1;31m]\e[0m\e[1;32m Ashes           \e[0m\e[1;31m [\e[0m\e[1;37m13\e[0m\e[1;31m]\e[0m\e[1;32m Codeschool\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m04\e[0m\e[1;31m]\e[0m\e[1;32m Atelierdune     \e[0m\e[1;31m [\e[0m\e[1;37m14\e[0m\e[1;31m]\e[0m\e[1;32m Colors\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m05\e[0m\e[1;31m]\e[0m\e[1;32m Atelierforest   \e[0m\e[1;31m [\e[0m\e[1;37m15\e[0m\e[1;31m]\e[0m\e[1;32m Default\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m06\e[0m\e[1;31m]\e[0m\e[1;32m Atelierheath    \e[0m\e[1;31m [\e[0m\e[1;37m16\e[0m\e[1;31m]\e[0m\e[1;32m Eighties\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m07\e[0m\e[1;31m]\e[0m\e[1;32m Atelierlakeside \e[0m\e[1;31m [\e[0m\e[1;37m17\e[0m\e[1;31m]\e[0m\e[1;32m Embers\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m08\e[0m\e[1;31m]\e[0m\e[1;32m Atelierseaside  \e[0m\e[1;31m [\e[0m\e[1;37m18\e[0m\e[1;31m]\e[0m\e[1;32m Flat\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m09\e[0m\e[1;31m]\e[0m\e[1;32m Bespin          \e[0m\e[1;31m [\e[0m\e[1;37m19\e[0m\e[1;31m]\e[0m\e[1;32m Google\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m10\e[0m\e[1;31m]\e[0m\e[1;32m Brewer          \e[0m\e[1;31m [\e[0m\e[1;37m20\e[0m\e[1;31m]\e[0m\e[1;32m Grayscale\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m21\e[0m\e[1;31m]\e[0m\e[1;32m Greenscreen     \e[0m\e[1;31m [\e[0m\e[1;37m31\e[0m\e[1;31m]\e[0m\e[1;32m Shapeshifter\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m22\e[0m\e[1;31m]\e[0m\e[1;32m Harmonic16      \e[0m\e[1;31m [\e[0m\e[1;37m32\e[0m\e[1;31m]\e[0m\e[1;32m Solarized\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m23\e[0m\e[1;31m]\e[0m\e[1;32m Isotope         \e[0m\e[1;31m [\e[0m\e[1;37m33\e[0m\e[1;31m]\e[0m\e[1;32m Summerfruit\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m24\e[0m\e[1;31m]\e[0m\e[1;32m Londontube      \e[0m\e[1;31m [\e[0m\e[1;37m34\e[0m\e[1;31m]\e[0m\e[1;32m Tomorrow\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m25\e[0m\e[1;31m]\e[0m\e[1;32m Marrakesh       \e[0m\e[1;31m [\e[0m\e[1;37m35\e[0m\e[1;31m]\e[0m\e[1;32m Twilight\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m26\e[0m\e[1;31m]\e[0m\e[1;32m Mocha           \e[0m\e[1;31m [\e[0m\e[1;37m36\e[0m\e[1;31m]\e[0m\e[1;32m Gruvbox\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m27\e[0m\e[1;31m]\e[0m\e[1;32m Monokai         \e[0m\e[1;31m [\e[0m\e[1;37m37\e[0m\e[1;31m]\e[0m\e[1;32m Solarized 2\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m28\e[0m\e[1;31m]\e[0m\e[1;32m Ocean           \e[0m\e[1;31m [\e[0m\e[1;37m38\e[0m\e[1;31m]\e[0m\e[1;32m One\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m29\e[0m\e[1;31m]\e[0m\e[1;32m Paraiso         \e[0m\e[1;31m [\e[0m\e[1;37m39\e[0m\e[1;31m]\e[0m\e[1;32m Black on White\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m30\e[0m\e[1;31m]\e[0m\e[1;32m Railscasts      \e[0m\e[1;31m [\e[0m\e[1;37m40\e[0m\e[1;31m]\e[0m\e[1;32m Spacemacs\e[0m\n"
printf "\e[0m\n"
read -p $' \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Select an option: \e[0m\e[1;96m\en' option
if [[ $option == 1 || $option == 01 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing 3024 Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/1.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m 3024 Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 2 || $option == 02 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Apathy Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/2.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Apathy Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 3 || $option == 03 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Ashes Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/3.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Ashes Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 4 || $option == 04 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierdune Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/4.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierdune Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 5 || $option == 05 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierforest Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/5.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierforest Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 6 || $option == 06 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierheath Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/6.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierheath Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 7 || $option == 07 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierlakeside Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/7.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierlakeside Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 8 || $option == 08 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierseaside Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/8.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierseaside Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 9 || $option == 09 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Bespin Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/9.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Bespin Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 10 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Brewer Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/10.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Brewer Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 11 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Bright Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/11.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Bright Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 12 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Chalk Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/12.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Chalk Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 13 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Codeschool Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/13.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Codeschool Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 14 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Colors Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/14.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Colors Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 15 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Default Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/15.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Default Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 16 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Eighties Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/16.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Eighties Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 17 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Embers Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/17.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Embers Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 18 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Flat Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/18.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Flat Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 19 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Google Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/19.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Google Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 20 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Grayscale Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/20.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Grayscale Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 21 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Greenscreen Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/21.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Greenscreen Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 22 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Harmonic16 Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/22.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Harmonic16 Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 23 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Isotope Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/23.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Isotope Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 24 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Londontube Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/24.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Londontube Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 25 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Marrakesh Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/25.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Marrakesh Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 26 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Mocha Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/26.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Mocha Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 27 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Monokai Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/27.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Monokai Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 28 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Ocean Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/28.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Ocean Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 29 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Paraiso Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/29.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Paraiso Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 30 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Railscasts Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/30.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Railscasts Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 31 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Shapeshifter Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/31.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Shapeshifter Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 32 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Solarized Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/32.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Solarized Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 33 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Summerfruit Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/33.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Summerfruit Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 34 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Tomorrow Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/34.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Tomorrow Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 35 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Twilight Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/35.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Twilight Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 36 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Gruvbox Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/36.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Gruvbox Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 37 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Solarized 2 Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/37.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Solarized 2 Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 38 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing One Light..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/38.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m One Light Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 39 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Black on White..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/39.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Black on White Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 40 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Spacemacs..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/light/40.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Spacemacs Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
else
printf " \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\e[1;93m Invalid option \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\n"
sleep 1
banner
menu
fi
}
darkthemes() {
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m01\e[0m\e[1;31m]\e[0m\e[1;32m 3024            \e[0m\e[1;31m [\e[0m\e[1;37m11\e[0m\e[1;31m]\e[0m\e[1;32m Bright\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m02\e[0m\e[1;31m]\e[0m\e[1;32m Apathy          \e[0m\e[1;31m [\e[0m\e[1;37m12\e[0m\e[1;31m]\e[0m\e[1;32m Chalk\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m03\e[0m\e[1;31m]\e[0m\e[1;32m Ashes           \e[0m\e[1;31m [\e[0m\e[1;37m13\e[0m\e[1;31m]\e[0m\e[1;32m Codeschool\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m04\e[0m\e[1;31m]\e[0m\e[1;32m Atelierdune     \e[0m\e[1;31m [\e[0m\e[1;37m14\e[0m\e[1;31m]\e[0m\e[1;32m Colors\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m05\e[0m\e[1;31m]\e[0m\e[1;32m Atelierforest   \e[0m\e[1;31m [\e[0m\e[1;37m15\e[0m\e[1;31m]\e[0m\e[1;32m Default\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m06\e[0m\e[1;31m]\e[0m\e[1;32m Atelierheath    \e[0m\e[1;31m [\e[0m\e[1;37m16\e[0m\e[1;31m]\e[0m\e[1;32m Eighties\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m07\e[0m\e[1;31m]\e[0m\e[1;32m Atelierlakeside \e[0m\e[1;31m [\e[0m\e[1;37m17\e[0m\e[1;31m]\e[0m\e[1;32m Embers\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m08\e[0m\e[1;31m]\e[0m\e[1;32m Atelierseaside  \e[0m\e[1;31m [\e[0m\e[1;37m18\e[0m\e[1;31m]\e[0m\e[1;32m Flat\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m09\e[0m\e[1;31m]\e[0m\e[1;32m Bespin          \e[0m\e[1;31m [\e[0m\e[1;37m19\e[0m\e[1;31m]\e[0m\e[1;32m Google\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m10\e[0m\e[1;31m]\e[0m\e[1;32m Brewer          \e[0m\e[1;31m [\e[0m\e[1;37m20\e[0m\e[1;31m]\e[0m\e[1;32m Grayscale\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m21\e[0m\e[1;31m]\e[0m\e[1;32m Greenscreen     \e[0m\e[1;31m [\e[0m\e[1;37m31\e[0m\e[1;31m]\e[0m\e[1;32m Shapeshifter\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m22\e[0m\e[1;31m]\e[0m\e[1;32m Harmonic16      \e[0m\e[1;31m [\e[0m\e[1;37m32\e[0m\e[1;31m]\e[0m\e[1;32m Solarized\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m23\e[0m\e[1;31m]\e[0m\e[1;32m Isotope         \e[0m\e[1;31m [\e[0m\e[1;37m33\e[0m\e[1;31m]\e[0m\e[1;32m Summerfruit\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m24\e[0m\e[1;31m]\e[0m\e[1;32m Londontube      \e[0m\e[1;31m [\e[0m\e[1;37m34\e[0m\e[1;31m]\e[0m\e[1;32m Tomorrow\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m25\e[0m\e[1;31m]\e[0m\e[1;32m Marrakesh       \e[0m\e[1;31m [\e[0m\e[1;37m35\e[0m\e[1;31m]\e[0m\e[1;32m Twilight\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m26\e[0m\e[1;31m]\e[0m\e[1;32m Mocha           \e[0m\e[1;31m [\e[0m\e[1;37m36\e[0m\e[1;31m]\e[0m\e[1;32m Gruvbox\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m27\e[0m\e[1;31m]\e[0m\e[1;32m Monokai         \e[0m\e[1;31m [\e[0m\e[1;37m37\e[0m\e[1;31m]\e[0m\e[1;32m Solarized 2\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m28\e[0m\e[1;31m]\e[0m\e[1;32m Ocean           \e[0m\e[1;31m [\e[0m\e[1;37m38\e[0m\e[1;31m]\e[0m\e[1;32m One\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m29\e[0m\e[1;31m]\e[0m\e[1;32m Paraiso         \e[0m\e[1;31m [\e[0m\e[1;37m39\e[0m\e[1;31m]\e[0m\e[1;32m Argonaut\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m30\e[0m\e[1;31m]\e[0m\e[1;32m Railscasts      \e[0m\e[1;31m [\e[0m\e[1;37m40\e[0m\e[1;31m]\e[0m\e[1;32m Materia\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m41\e[0m\e[1;31m]\e[0m\e[1;32m Dracula         \e[0m\e[1;31m [\e[0m\e[1;37m51\e[0m\e[1;31m]\e[0m\e[1;32m White on Black\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m42\e[0m\e[1;31m]\e[0m\e[1;32m Gnometerm       \e[0m\e[1;31m [\e[0m\e[1;37m52\e[0m\e[1;31m]\e[0m\e[1;32m Wild Cherry\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m43\e[0m\e[1;31m]\e[0m\e[1;32m Gotham          \e[0m\e[1;31m [\e[0m\e[1;37m53\e[0m\e[1;31m]\e[0m\e[1;32m Zenburn\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m44\e[0m\e[1;31m]\e[0m\e[1;32m Material\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m45\e[0m\e[1;31m]\e[0m\e[1;32m Nancy\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m46\e[0m\e[1;31m]\e[0m\e[1;32m Neon\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m47\e[0m\e[1;31m]\e[0m\e[1;32m Nord\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m48\e[0m\e[1;31m]\e[0m\e[1;32m Rydgel\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m49\e[0m\e[1;31m]\e[0m\e[1;32m Smyck\e[0m\n"
printf "\e[0m\e[1;31m [\e[0m\e[1;37m50\e[0m\e[1;31m]\e[0m\e[1;32m Tomorrow Night\e[0m\n"
printf "\e[0m\n"
read -p $' \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Select an option: \e[0m\e[1;96m\en' option
if [[ $option == 1 || $option == 01 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing 3024 Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/1.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m 3024 Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 2 || $option == 02 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Apathy Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/2.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Apathy Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 3 || $option == 03 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Ashes Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/3.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Ashes Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 4 || $option == 04 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierdune Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/4.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierdune Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 5 || $option == 05 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierforest Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/5.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierforest Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 6 || $option == 06 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierheath Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/6.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierheath Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 7 || $option == 07 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierlakeside Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/7.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierlakeside Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 8 || $option == 08 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Atelierseaside Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/8.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Atelierseaside Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 9 || $option == 09 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Bespin Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/9.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Bespin Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 10 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Brewer Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/10.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Brewer Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 11 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Bright Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/11.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Bright Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 12 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Chalk Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/12.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Chalk Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 13 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Codeschool Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/13.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Codeschool Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 14 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Colors Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/14.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Colors Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 15 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Default Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/15.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Default Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 16 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Eighties Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/16.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Eighties Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 17 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Embers Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/17.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Embers Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 18 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Flat Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/18.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Flat Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 19 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Google Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/19.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Google Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 20 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Grayscale Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/20.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Grayscale Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 21 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Greenscreen Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/21.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Greenscreen Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 22 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Harmonic16 Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/22.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Harmonic16 Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 23 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Isotope Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/23.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Isotope Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 24 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Londontube Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/24.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Londontube Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 25 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Marrakesh Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/25.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Marrakesh Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 26 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Mocha Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/26.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Mocha Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 27 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Monokai Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/27.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Monokai Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 28 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Ocean Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/28.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Ocean Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 29 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Paraiso Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/29.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Paraiso Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 30 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Railscasts Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/30.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Railscasts Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 31 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Shapeshifter Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/31.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Shapeshifter Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 32 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Solarized Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/32.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Solarized Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 33 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Summerfruit Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/33.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Summerfruit Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 34 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Tomorrow Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/34.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Tomorrow Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 35 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Twilight Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/35.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Twilight Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 36 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Gruvbox Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/36.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Gruvbox Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 37 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Solarized 2 Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/37.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Solarized 2 Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 38 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing One Dark..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/38.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m One Dark Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 39 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Argonaut..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/39.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Argonaut Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 40 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Materia..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/40.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Materia Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 41 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Dracula..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/41.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Dracula Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 42 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Gnometerm..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/42.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Gnometerm Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 43 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Gotham..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/43.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Gotham Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 44 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Material..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/44.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Material Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 45 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Nancy..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/45.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Nancy Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 46 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Neon..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/46.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Neon Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 47 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Nord..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/47.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Nord Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 48 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Rydgel..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/48.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Rydgel Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 49 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Smyck..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/49.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Smyck Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 50 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Tomorrow Night..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/50.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Tomorrow Night Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 51 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing White on Black..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/51.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m White on Black Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 52 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Wild Cherry..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/52.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Wild Cherry Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
elif [[ $option == 53 ]]; then
printf "\e[0m\n"
printf "\e[0m\e[1;32m Installing Zenburn..\e[0m\n"
rm $HOME/.termux/colors.properties
cp .corefiles/theme/dark/53.properties $HOME/.termux/colors.properties
am broadcast --user 0 -a com.termux.app.reload_style com.termux > /dev/null
sleep 2
printf "\e[0m\n"
printf "\e[0m\e[1;32m Setting Up..\e[0m\n"
termux-reload-settings
printf "\e[0m\n"
printf "\e[0m\e[1;32m Zenburn Successfully Installed !!\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
exit 1
else
printf " \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\e[1;93m Invalid option \e[1;91m[\e[0m\e[1;97m!\e[0m\e[1;91m]\e[0m\n"
sleep 1
banner
menu
fi
}
banner
menu
